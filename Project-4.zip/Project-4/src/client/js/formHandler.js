import { validateURL } from './vallidateURL';

function handleSubmit(event) {
  event.preventDefault();
  const inputUrl = document.getElementById('name').value;

  if (Client.validateURL(inputUrl)) {
    console.log('Valid URL, Building Request');
    postData('/add', {
      url: inputUrl,
    }).then(function (data) {
      updateUI(data);
    });
    return false;
  } else{
    console.log('Invalid URL');
    document.getElementById('error').innerHTML = "Please enter valid URL";
  }
}
const postData = async (url = '', data = {}) => {
  console.log(data);
  const response = await fetch(url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data), // body data type must match "Content-Type" header
  });
  try {
    const newData = await response.json();
    console.log(newData);
    return newData;
  } catch (error) {
    console.log('Error', error);
  }
};

const updateUI = async (res) => {
  console.log(res);
  document.getElementById('polarity').innerHTML = "Polarity :" + res.polarity;
  document.getElementById('subjectivity').innerHTML = "Subjectivity :" + res.subjectivity;
  document.getElementById('polarity_confidence').innerHTML = "Polarity Confidence :" + res.polarity_confidence;
  document.getElementById('subjectivity_confidence').innerHTML = "Subjectivity Confidence :" + res.subjectivity_confidence;
  document.getElementById('text').innerHTML = "Text :" + res.text;
};

//postData('/add', data);
export { handleSubmit };
