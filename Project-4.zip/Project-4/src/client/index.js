import { validateURL } from './js/vallidateURL';
import { handleSubmit } from './js/formHandler';

import './styles/resets.scss';
import './styles/base.scss';
import './styles/form.scss';
import './styles/header.scss';
import './styles/footer.scss';

console.log(validateURL);
console.log(handleSubmit);

export { validateURL, handleSubmit };

alert ("I exists");