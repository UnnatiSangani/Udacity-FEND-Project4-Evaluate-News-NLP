import { validateURL } from '../src/client/js/validateURL';

const url = document.getElementById('name').value;

describe('Validate URL', () => {
    it('Check if the URL passed is valid', () => {
      expect(validateURL(url)).toEqual(true);
    });
});