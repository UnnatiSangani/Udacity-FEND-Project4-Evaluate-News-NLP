import { handleSubmit } from '../src/client/js/formHandler';

test('testing that function is defined', () => {
    expect(handleSubmit).toBeDefined();
});